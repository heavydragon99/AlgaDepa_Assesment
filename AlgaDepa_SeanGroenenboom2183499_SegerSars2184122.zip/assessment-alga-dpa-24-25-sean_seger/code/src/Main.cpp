#include "Controller.h"

int main() {

    Controller ctrl;
    ctrl.initialize();
    ctrl.run();

    return 0;
}
